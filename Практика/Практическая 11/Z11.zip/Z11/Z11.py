import requests
from tkinter import *
import json

def repo():
    def delete():
        pole.delete(0,END)
    adress = f"https://api.github.com/users/{pole.get()}"
    infa = requests.get(adress).json() 
    company = infa['company'] 
    created_at = infa['created_at'] 
    email = infa['email'] 
    id = infa['id'] 
    name = infa['name'] 
    url = infa['url'] 
    result = {'company': company, 'created_at': created_at, 'email': email, 'id': id, 'name': name, 'url': url} 
    with open('info_o_repo.json', 'w') as f: 
        json.dump(result, f)
    kon = Label(text=f'Данные по вашему запросу \n находяться в \n info_o_repo.json',font='Times 15', fg='red', bg='black')
    kon.place(relx=.5, rely=.7, anchor="center")
    delete()
okno = Tk()
okno.title('Информация о выбранном репозитории')
okno.geometry('402x300')
okno.resizable(width=False, height=False)
holst = Canvas(okno, width=402, height=301, bg = 'black')
holst.pack()

text = Label(text='Введите имя репозитория \n и нажите на кнопку',font='Times 20', fg='red', bg='black')
text.place(relx=.5, rely=.2, anchor="center")

pole = Entry()
pole.place(relx=.5, rely=.4, anchor="center")

knopka = Button(text='BUT', width=10, height=1, bg='red',fg='black',font='Times 10', command=repo)
knopka.place(relx=.5, rely=.5, anchor="center")

okno.mainloop()